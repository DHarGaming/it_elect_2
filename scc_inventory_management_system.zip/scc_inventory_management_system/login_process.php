<?php
session_start();
require_once 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['txtuser'] ?? '';
    $password = $_POST['txtpass'] ?? '';

    $sql = "SELECT * FROM admin_tbl WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {

            // PLAIN TEXT PASSWORD CHECK
            if ($password === $row['password']) {

                $_SESSION['a_id'] = $row['a_id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['position'] = $row['position'];

                echo "success";
            } else {
                echo "Invalid password";
            }

        } else {
            echo "User not found";
        }
    } else {
        echo "Query failed";
    }
}
?>
