<?php
include 'connection.php';

$message = "";

if (isset($_POST['save_dept'])) {

    $dept_name = $_POST['dept_name'];
    $description = $_POST['description'];

    // Check if department already exists
    $check = $conn->query("SELECT * FROM dept_tbl WHERE dept_name='$dept_name'");

    if ($check->num_rows > 0) {

        $message = '<div class="alert alert-danger">
                        Department already exists!
                    </div>';

    } else {

        $sql = "INSERT INTO dept_tbl (dept_name, description)
                VALUES ('$dept_name', '$description')";

        if ($conn->query($sql)) {

            $message = '<div class="alert alert-success">
                            Department Successfully Registered!
                        </div>';

        } else {

            $message = '<div class="alert alert-danger">
                            Error adding department
                        </div>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Register Department</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

<div id="wrapper">

    <!-- Sidebar -->
    <?php include 'menubar.php'; ?>
    <!-- End Sidebar -->

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">

            <!-- Topbar -->
            <?php include 'header.php'; ?>
            <!-- End Topbar -->


<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">Register Department</h1>

    <div class="card shadow mb-4">
        <div class="card-body">

            <?php echo $message; ?>

            <form method="POST">

                <div class="form-group">
                    <label>Department Name</label>
                    <input type="text" name="dept_name" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <input type="text" name="description" class="form-control" required>
                </div>

                <button type="submit" name="save_dept"
                        class="btn btn-primary">
                    Save Department
                </button>

                <a href="department_list.php" class="btn btn-secondary">
                    View List
                </a>

            </form>

        </div>
    </div>

</div>

</div>

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>&copy; SCC Inventory System 2026</span>
                </div>
            </div>
        </footer>

    </div>
</div>  <!--end of wrapper -->

<script>
setTimeout(function(){
    $('.alert').fadeOut('slow');
},3000);
</script>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>

</body>
</html>