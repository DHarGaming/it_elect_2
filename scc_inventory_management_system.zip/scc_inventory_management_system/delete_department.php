<?php
include 'connection.php';

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $conn->query("DELETE FROM dept_tbl WHERE dept_id='$id'");

    header("Location: department_list.php");
}
?>