<div class="modal fade" id="logoutModal" tabindex="-1">
<div class="modal-dialog">
<div class="modal-content">

<div class="modal-header">
<h5 class="modal-title">Ready to Leave?</h5>
<button class="close" data-dismiss="modal">
<span>×</span>
</button>
</div>

<div class="modal-body">
Select "Logout" if you want to end session.
</div>

<div class="modal-footer">
<button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
<a class="btn btn-primary" href="logout.php">Logout</a>
</div>

</div>
</div>
</div>