<?php
session_start();
include 'connection.php';

$message = "";

/* ===============================
   LOAD DEPARTMENTS SAFELY
================================= */
$departments = [];

$dept_query = $conn->query("SELECT * FROM dept_tbl"); 

if ($dept_query) {
    while ($row = $dept_query->fetch_assoc()) {
        $departments[] = $row;
    }
} else {
    die("Department table error: " . $conn->error);
}


/* ===============================
   REGISTER ITEM
================================= */
if (isset($_POST['register'])) {

    $item_id = $_POST['item_id'] ?? '';
    $item_name = $_POST['item_name'] ?? '';
    $item_description = $_POST['item_description'] ?? '';
    $quantity = $_POST['quantity'] ?? 0;
    $item_type = $_POST['item_type'] ?? '';
    $dept_id = $_POST['dept_id'] ?? 0;
    $date_register = $_POST['date_register'] ?? '';

    // CHECK IF ITEM EXISTS
    $check = $conn->prepare("SELECT item_id FROM item_tbl WHERE item_id = ?");
    $check->bind_param("s", $item_id);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {

        $message = '<div class="alert alert-dark">Item ID already exists!</div>';

    } else {

        $stmt = $conn->prepare("INSERT INTO item_tbl 
            (item_id, item_name, item_description, quantity, item_type, dept_id, date_register) 
            VALUES (?, ?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("sssisss", 
            $item_id, 
            $item_name, 
            $item_description, 
            $quantity, 
            $item_type, 
            $dept_id, 
            $date_register
        );

        if ($stmt->execute()) {

            $message = '<div class="alert alert-success">Item Successfully Registered!</div>';

            $_POST = []; // Clear form

        } else {

            $message = '<div class="alert alert-danger">Error: '.$stmt->error.'</div>';
        }

        $stmt->close();
    }

    $check->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Register Items</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

     <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
            include 'menubar.php';
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
                <div id="content-wrapper" class="d-flex flex-column">

                    <!-- Main Content -->
                    <div id="content">

                            <!-- Topbar -->
                            <?php
                                include 'header.php';
                         ?>
                            <!-- End of Topbar -->




    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block bg-register-image">
                        <img src="img/SCC.png" width="100%" style="margin-top: 40px; margin-left: 20px;">
                    </div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Register Items</h1>
                            </div>
                            <form class="user" method="POST">

                                <?php 
                                    if (!empty($message)) {
                                        echo $message;
                                    }
                                ?>

                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" name="item_id" class="form-control form-control-user"
                                            placeholder="Item ID" required>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" name="item_name" class="form-control form-control-user"
                                            placeholder="Item Name" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <input type="text" name="item_description" class="form-control form-control-user"
                                        placeholder="Item Description" required>
                                </div>

                                <div class="form-group">
                                    <input type="text" name="item_type" class="form-control form-control-user"
                                        placeholder="Item Type" required>
                                </div>

                                <div class="form-group">
                                    <select name="dept_id" class="form-control form-control" required>
                                        <option value="">Select Department</option>

                                        <?php 
                                        $selected_dept = $_POST['dept_id'] ?? '';
                                        foreach ($departments as $dept): 
                                        ?>
                                            <option value="<?php echo $dept['dept_id']; ?>"
                                                <?php if ($selected_dept == $dept['dept_id']) echo 'selected'; ?>>
                                                
                                                <?php echo $dept['dept_name']; ?>
                                            </option>
                                        <?php endforeach; ?>

                                    </select>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="date" name="date_register" class="form-control form-control-user"
                                            required>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="number" name="quantity" class="form-control form-control-user"
                                            placeholder="Quantity" required>
                                    </div>
                                </div>

                                <button type="submit" name="register" 
                                    class="btn btn-primary btn-user btn-block">
                                    Register Item
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

            </div>
            <!-- End of Main Content -->

             <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>&copy; SCC Inventory System 2026</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
            </div>
    <!-- End of Page Wrapper -->

     </div>
    <!-- End of Page Wrapper -->

    <script>
    setTimeout(function(){
        $('.alert').fadeOut('slow');
    },3000);
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>