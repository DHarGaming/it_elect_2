<?php
include 'connection.php';

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM item_tbl WHERE item_id=?");
    $stmt->bind_param("s", $id);

    if ($stmt->execute()) {
        header("Location: list_of_items.php");
        exit();
    } else {
        echo "Delete Failed";
    }

} else {
    header("Location: list_of_items.php");
}
?>