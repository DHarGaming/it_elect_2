<?php
include 'connection.php';

if (!isset($_GET['id'])) {
    header("Location: department_list.php");
    exit();
}

$id = $_GET['id'];

// FETCH EXISTING DATA
$result = $conn->query("SELECT * FROM dept_tbl WHERE dept_id='$id'");
$row = $result->fetch_assoc();

if (!$row) {
    header("Location: department_list.php");
    exit();
}

// UPDATE PROCESS
if (isset($_POST['update_dept'])) {

    $dept_name = $_POST['dept_name'];
    $description = $_POST['description'];

    $sql = "UPDATE dept_tbl 
            SET dept_name='$dept_name',
                description='$description'
            WHERE dept_id='$id'";

    if ($conn->query($sql)) {
        echo "<script>
                alert('Department Updated Successfully!');
                window.location='department_list.php';
              </script>";
    } else {
        echo "<script>alert('Error updating department');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Update Department</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

<div id="wrapper">

    <!-- Sidebar -->
    <?php include 'menubar.php'; ?>
    <!-- End Sidebar -->

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">

            <!-- Topbar -->
            <?php include 'header.php'; ?>
            <!-- End Topbar -->


<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">Update Department</h1>

    <div class="card shadow mb-4">
        <div class="card-body">

            <form method="POST">

                <div class="form-group">
                    <label>Department Name</label>
                    <input type="text" name="dept_name"
                           value="<?php echo $row['dept_name']; ?>"
                           class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <input type="text" name="description"
                           value="<?php echo $row['description']; ?>"
                           class="form-control" required>
                </div>

                <button type="submit" name="update_dept"
                        class="btn btn-secondary">
                    Update Department
                </button>

                <a href="department_list.php"
                   class="btn btn-danger">
                    Cancel
                </a>

            </form>

        </div>
    </div>

</div>

</div>

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>&copy; SCC Student Profile 2026</span>
                </div>
            </div>
        </footer>

    </div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>

</body>
</html>