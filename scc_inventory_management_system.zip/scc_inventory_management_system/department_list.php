<?php
include 'connection.php';

$message = "";

/* ================= HANDLE SUCCESS MESSAGE AFTER REDIRECT ================= */
if(isset($_GET['success'])){

    if($_GET['success'] == 'add'){
        $message = '
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Department Successfully Registered!
        </div>';
    }

    if($_GET['success'] == 'update'){
        $message = '
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Department Updated Successfully!
        </div>';
    }

    if($_GET['success'] == 'delete'){
        $message = '
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Department Deleted Successfully!
        </div>';
    }
}


/* ================= ADD DEPARTMENT ================= */
if (isset($_POST['save_dept'])) {

    $dept_name = $_POST['dept_name'];
    $description = $_POST['description'];

    /* ================= CHECK IF DEPARTMENT EXISTS ================= */
    $check = $conn->prepare("SELECT dept_id FROM dept_tbl WHERE dept_name = ?");
    $check->bind_param("s", $dept_name);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {

        // Already exists
        $message = '
        <div class="alert alert-danger alert-dismissible fade show">
            Department already exists!
        </div>';

    } else {

        /* ================= INSERT DEPARTMENT ================= */
        $stmt = $conn->prepare("INSERT INTO dept_tbl (dept_name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $dept_name, $description);

        if ($stmt->execute()) {

            //  Redirect to prevent duplicate submit on refresh
            header("Location: department_list.php?success=add");
            exit();

        } else {

            $message = '
            <div class="alert alert-danger alert-dismissible fade show">
                Error adding department
            </div>';
        }

        $stmt->close();
    }

    $check->close();
}

/* ================= DELETE DEPARTMENT ================= */
if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM dept_tbl WHERE dept_id=?");
    $stmt->bind_param("i", $id);

    if($stmt->execute()){
        header("Location: department_list.php?success=delete");
        exit();
    }else{
        $message = '
        <div class="alert alert-danger alert-dismissible fade show">
            Error deleting department
        </div>';
    }

    $stmt->close();
}


/* ================= UPDATE DEPARTMENT ================= */
if(isset($_POST['update_department'])){

    $dept_id = $_POST['dept_id'];
    $dept_name = $_POST['dept_name'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE dept_tbl SET dept_name=?, description=? WHERE dept_id=?");
    $stmt->bind_param("ssi", $dept_name, $description, $dept_id);

    if($stmt->execute()){
        header("Location: department_list.php?success=update");
        exit();
    }else{
        $message = '
        <div class="alert alert-danger alert-dismissible fade show">
            Error updating department
        </div>';
    }

    $stmt->close();
}


/* ================= FETCH DEPARTMENTS ================= */
$result = $conn->query("SELECT * FROM dept_tbl ORDER BY dept_id DESC");


/* ================= COUNT DEPARTMENTS ================= */
$countQuery = $conn->query("SELECT COUNT(dept_id) AS total FROM dept_tbl");
$countRow = $countQuery->fetch_assoc();
$totalDepartments = $countRow['total'];

?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>List Department</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

<div id="wrapper">

    <!-- Sidebar -->
    <?php include 'menubar.php'; ?>
    <!-- End Sidebar -->

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">

            <!-- Topbar -->
            <?php include 'header.php'; ?>
            <!-- End Topbar -->

<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">Department List</h1>

        <?php if(!empty($message)){ echo $message; } ?>

                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Departments
                                        </div>

                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $totalDepartments; ?>
                                        </div>
                                    </div>

                                    <div class="col-auto">
                                        <i class="fas fa-building fa-2x text-gray-300"></i>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- DEPARTMENT TABLE -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">
                            Department List
                        </h6>

                        <!-- ADD DEPARTMENT BUTTON -->
                        <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#addDeptModal">
                            <i class="fas fa-plus"></i> Add Department
                        </button>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">

                            <table class="table table-bordered" id="dataTable" width="100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Department Name</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <?php
                                    if($result && $result->num_rows > 0){
                                    while($row = $result->fetch_assoc()){
                                ?>

                                <tr>
                                    <td><?php echo $row['dept_id']; ?></td>
                                    <td><?php echo $row['dept_name']; ?></td>
                                    <td><?php echo $row['description']; ?></td>
                                    <td>
                                    <!-- UPDATE BUTTON -->
                                    <button class="btn btn-primary btn-sm"
                                            data-toggle="modal"
                                            data-target="#updateModal"
                                            onclick="setUpdateData(
                                                '<?php echo $row['dept_id']; ?>',
                                                '<?php echo $row['dept_name']; ?>',
                                                '<?php echo $row['description']; ?>'
                                            )"><i class="fas fa-edit"></i>
                                            Update
                                        </button>

                                    <!-- DELETE -->
                                    <a href="?delete=<?php echo $row['dept_id']; ?>"
                                        class="btn btn-secondary btn-sm"
                                        onclick="return confirm('Delete this department?')">
                                        Delete
                                    </a>

                                    </td>
                                </tr>

                                <?php
                                }
                                        } else {
                                    echo "<tr><td colspan='4' class='text-center'>No Department Found</td></tr>";
                                    }
                                ?>

                            
                            </table>

                        </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto text-center">
                <span>&copy; SCC Inventory System 2026</span>
            </div>
        </footer>

    </div>
</div>


<!-- ================= ADD DEPARTMENT MODAL ================= -->

<div class="modal fade" id="addDeptModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Add Department</h5>
                <button class="close text-white" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body">

                <form method="POST">

                    <div class="form-group">
                        <label>Department Name</label>
                        <input type="text" name="dept_name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control"></textarea>
                    </div>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" name="save_dept" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>

                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                </form>

            </div>

        </div>
    </div>
</div>

<!-- UPDATE MODAL -->
<div class="modal fade" id="updateModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">

      <form method="POST">

        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Update Department</h5>
          <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
        </div>

        <div class="modal-body">

            <input type="hidden" name="dept_id" id="update_dept_id">

            <div class="mb-3">
                <label>Department Name</label>
                <input type="text" name="dept_name" id="update_dept_name"
                    class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Description</label>
                <textarea name="description" id="update_description"
                    class="form-control" required></textarea>
            </div>

        </div>

        <div class="modal-footer">
          <button type="submit" name="update_department"
            class="btn btn-primary"><i class="fas fa-save"></i>
            Save Changes
          </button>
        </div>

      </form>

    </div>
  </div>
</div>

    <script>
        function setUpdateData(id, name, description) {

            $("#update_dept_id").val(id);
            $("#update_dept_name").val(name);
            $("#update_description").val(description);

        }
    </script>

    <script> setTimeout(function(){$('.alert').fadeOut('slow');},3000);</script>

<!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>
</html>


                
