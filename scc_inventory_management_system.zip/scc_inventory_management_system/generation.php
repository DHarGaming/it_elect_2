<?php
include 'connection.php';

require_once('tcpdf/tcpdf.php');

/* ===============================
   CREATE PDF
================================ */

$pdf = new TCPDF();
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('SCC Inventory System');
$pdf->SetTitle('Inventory Report');

/* ===============================
   FONT STYLE (TIMES NEW ROMAN)
================================ */
$pdf->SetFont('times', '', 12);

$pdf->AddPage();

/* ===============================
   REPORT HEADER
================================ */

$html = '
<table width="50%" cellpadding="5" align="center">
<tr>
    <td  align="center">
        <img src="img/scclogo.jpg" width="100px">
    </td>

    <td width="100%" align="center">
        <h2>Southern City Colleges</h2>
        <span>Pillar Street, Zamboanga City</span><br>
        <h3>Inventory Report</h3>
        <span>Date Generated: '.date("F d, Y").'</span>
    </td>
</tr>
</table>

<br><br>

<table border="1" cellpadding="5">
<tr style="background-color:#f2f2f2; font-weight:bold;">
<th>Item ID</th>
<th>Name</th>
<th>Description</th>
<th>Quantity</th>
<th>Type</th>
<th>Department</th>
<th>Date Registered</th>
</tr>
';

/* ===============================
   FETCH DATA
================================ */

$query = "SELECT item_tbl.*, dept_tbl.dept_name 
          FROM item_tbl
          LEFT JOIN dept_tbl
          ON item_tbl.dept_id = dept_tbl.dept_id
          ORDER BY item_tbl.date_register DESC";

$result = $conn->query($query);

if($result && $result->num_rows > 0){

    while($row = $result->fetch_assoc()){

        $html .= '
        <tr>
            <td>'.$row['item_id'].'</td>
            <td>'.$row['item_name'].'</td>
            <td>'.$row['item_description'].'</td>
            <td>'.$row['quantity'].'</td>
            <td>'.$row['item_type'].'</td>
            <td>'.$row['dept_name'].'</td>
            <td>'.$row['date_register'].'</td>
        </tr>
        ';
    }
}

$html .= '</table>';

/* ===============================
   OUTPUT PDF
================================ */

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('Inventory_Report.pdf', 'D');
?>