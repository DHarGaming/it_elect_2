<?php
include 'connection.php';

/* ============================
   AREA CHART - Items Per Month
============================ */
$areaQuery = "
    SELECT DATE_FORMAT(date_register, '%Y-%m') AS month,
           COUNT(*) AS total
    FROM item_tbl
    GROUP BY month
    ORDER BY month ASC
";
$areaResult = $conn->query($areaQuery);

$months = [];
$monthTotals = [];

while ($row = $areaResult->fetch_assoc()) {
    $months[] = $row['month'];
    $monthTotals[] = $row['total'];
}

/* ============================
   BAR CHART - Quantity per Department
============================ */
$barQuery = "
    SELECT d.dept_name, SUM(i.quantity) AS total_qty
    FROM item_tbl i
    JOIN dept_tbl d ON i.dept_id = d.dept_id
    GROUP BY d.dept_name
";
$barResult = $conn->query($barQuery);

$deptNames = [];
$deptQty = [];

while ($row = $barResult->fetch_assoc()) {
    $deptNames[] = $row['dept_name'];
    $deptQty[] = $row['total_qty'];
}

/* ============================
   PIE CHART - Item Type Count
============================ */
$pieQuery = "
    SELECT item_type, COUNT(*) AS total
    FROM item_tbl
    GROUP BY item_type
";
$pieResult = $conn->query($pieQuery);

$itemTypes = [];
$typeTotals = [];

while ($row = $pieResult->fetch_assoc()) {
    $itemTypes[] = $row['item_type'];
    $typeTotals[] = $row['total'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Charts</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-8 col-lg-7">

                            <!-- Area Chart -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Area Chart</h6>
                                </div>
                                <div class="card-body">
                                    <div class="chart-area">
                                        <canvas id="myAreaChart"></canvas>
                                    </div> 
                                </div>
                            </div>

                            <!-- Bar Chart -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Bar Chart</h6>
                                </div>
                                <div class="card-body">
                                    <div class="chart-bar">
                                        <canvas id="myBarChart"></canvas>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- Donut Chart -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Donut Chart</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="chart-pie pt-4">
                                        <canvas id="myPieChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

// =============================
// AREA CHART - Items Per Month
// =============================
var ctxArea = document.getElementById("myAreaChart").getContext('2d');

var myAreaChart = new Chart(ctxArea, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($months); ?>,
        datasets: [{
            label: "Items Registered",
            data: <?php echo json_encode($monthTotals); ?>,
            backgroundColor: "rgba(78,115,223,0.2)",
            borderColor: "rgba(78,115,223,1)",
            borderWidth: 2,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});


// =============================
// BAR CHART - Quantity per Department
// =============================
var ctxBar = document.getElementById("myBarChart").getContext('2d');

var myBarChart = new Chart(ctxBar, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($deptNames); ?>,
        datasets: [{
            label: "Total Quantity",
            data: <?php echo json_encode($deptQty); ?>,
            backgroundColor: "rgba(28,200,138,0.7)"
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});


// =============================
// PIE CHART - Item Type Count
// =============================
var ctxPie = document.getElementById("myPieChart").getContext('2d');

var myPieChart = new Chart(ctxPie, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode($itemTypes); ?>,
        datasets: [{
            data: <?php echo json_encode($typeTotals); ?>,
            backgroundColor: [
                "#4e73df",
                "#1cc88a",
                "#36b9cc",
                "#f6c23e",
                "#e74a3b"
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

</script>




</body>

</html>