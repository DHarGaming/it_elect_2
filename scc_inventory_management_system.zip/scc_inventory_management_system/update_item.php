<?php
include 'connection.php';

if (!isset($_GET['id'])) {
    header("Location: list_of_items.php");
    exit();
}

$id = $_GET['id'];

// FETCH EXISTING ITEM
$result = $conn->query("SELECT * FROM item_tbl WHERE item_id='$id'");
$item = $result->fetch_assoc();

if (!$item) {
    header("Location: list_of_items.php");
    exit();
}

// UPDATE PROCESS
if (isset($_POST['update_item'])) {

    $item_name = $_POST['item_name'];
    $item_description = $_POST['item_description'];
    $quantity = $_POST['quantity'];
    $item_type = $_POST['item_type'];
    $dept_id = $_POST['dept_id'];

    $sql = "UPDATE item_tbl SET
                item_name='$item_name',
                item_description='$item_description',
                quantity='$quantity',
                item_type='$item_type',
                dept_id='$dept_id'
            WHERE item_id='$id'";

    if ($conn->query($sql)) {
        echo "<script>
                alert('Item Updated Successfully!');
                window.location='list_of_items.php';
              </script>";
    } else {
        echo "<script>alert('Error updating item');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Update Item</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

<div id="wrapper">

    <!-- Sidebar -->
    <?php include 'menubar.php'; ?>
    <!-- End Sidebar -->

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">

            <!-- Topbar -->
            <?php include 'header.php'; ?>
            <!-- End Topbar -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">Update Item</h1>

    <div class="card shadow mb-4">
        <div class="card-body">

            <form method="POST">

                <div class="form-group">
                    <label>Item ID</label>
                    <input type="text" value="<?php echo $item['item_id']; ?>"
                           class="form-control" readonly>
                </div>

                <div class="form-group">
                    <label>Item Name</label>
                    <input type="text" name="item_name"
                           value="<?php echo $item['item_name']; ?>"
                           class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <input type="text" name="item_description"
                           value="<?php echo $item['item_description']; ?>"
                           class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Quantity</label>
                    <input type="number" name="quantity"
                           value="<?php echo $item['quantity']; ?>"
                           class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Item Type</label>
                    <input type="text" name="item_type"
                           value="<?php echo $item['item_type']; ?>"
                           class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Department</label>
                    <select name="dept_id" class="form-control" required>
                        <?php
                        $dept = $conn->query("SELECT * FROM dept_tbl");
                        while ($row = $dept->fetch_assoc()) {

                            $selected = ($row['dept_id'] == $item['dept_id']) ? "selected" : "";

                            echo "<option value='".$row['dept_id']."' $selected>"
                                .$row['dept_name'].
                                "</option>";
                        }
                        ?>
                    </select>
                </div>

                <button type="submit" name="update_item"
                        class="btn btn-secondary">
                    Update Item
                </button>

                <a href="list_of_items.php"
                   class="btn btn-danger">
                    Cancel
                </a>

            </form>

        </div>
    </div>

</div>

</div>

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                   <span>&copy; SCC Inventory System 2026</span>
                </div>
            </div>
        </footer>

    </div>
</div> <!--end of wrapper -->