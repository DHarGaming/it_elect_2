<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "it_elect_02_db";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
