<?php
include 'connection.php';

$message = "";

/* ================= UPDATE ITEM FUNCTION ================= */
function updateItem($conn) {

    if(isset($_POST['update_item']) && isset($_POST['update_id'])){

        $id = $_POST['update_id'];
        $item_name = $_POST['item_name'] ?? '';
        $item_description = $_POST['item_description'] ?? '';
        $quantity = $_POST['quantity'] ?? 0;
        $item_type = $_POST['item_type'] ?? '';
        $dept_id = $_POST['dept_id'] ?? '';

        $stmt = $conn->prepare("UPDATE item_tbl 
                                SET item_name=?,
                                    item_description=?,
                                    quantity=?,
                                    item_type=?,
                                    dept_id=?
                                WHERE item_id=?");

        $stmt->bind_param(
            "ssissi",
            $item_name,
            $item_description,
            $quantity,
            $item_type,
            $dept_id,
            $id
        );

        if($stmt->execute()){
            return '<div class="alert alert-success">
                        Item Updated Successfully
                    </div>';
        } else {
            return '<div class="alert alert-danger">
                        Update Failed
                    </div>';
        }

        $stmt->close();
    }

    return "";
}

/* ================= CALL UPDATE FUNCTION ================= */
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $message = updateItem($conn);
}

/* ================= TOTAL COUNTS ================= */
$total_items_result = $conn->query("SELECT COUNT(*) as total FROM item_tbl");
$total_items = $total_items_result ? $total_items_result->fetch_assoc()['total'] : 0;

$total_quantity_result = $conn->query("SELECT SUM(quantity) as total_qty FROM item_tbl");
$total_quantity = $total_quantity_result ? $total_quantity_result->fetch_assoc()['total_qty'] : 0;
$total_quantity = $total_quantity ?? 0;

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Inventories</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

<div id="wrapper">

    <?php include 'menubar.php'; ?>

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">

            <?php include 'header.php'; ?>

            <div class="container-fluid">

                <h1 class="h3 mb-4 text-gray-800">List of Registered Items</h1>

                    <?php if(!empty($message)) {echo $message;} ?>

                <!-- SUMMARY CARDS -->
                <div class="row mb-4">

                    <div class="col-md-6">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Registered Items
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php echo $total_items; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Total Quantity in Inventory
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php echo $total_quantity; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- INVENTORY TABLE -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">
                            Registered List
                        </h6>

                        <!-- ADD ITEM BUTTON -->
                        <button class="btn btn-primary btn-sm mb-3" data-toggle="modal" data-target="#addItemModal">
                            <i class="fas fa-plus"></i> Add List Item
                        </button>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">

                            <table class="table table-bordered" id="dataTable" width="100%">
                                <thead>
                                    <tr>
                                        <th>Item ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Quantity</th>
                                        <th>Type</th>
                                        <th>Department</th>
                                        <th>Date Registered</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                        

                                <?php
                                $query = "SELECT item_tbl.*, item_tbl.dept_id, dept_tbl.dept_name 
                                          FROM item_tbl
                                          LEFT JOIN dept_tbl
                                          ON item_tbl.dept_id = dept_tbl.dept_id
                                          ORDER BY item_tbl.date_register DESC";

                                $result = $conn->query($query);

                                if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                ?>

                                <tr>
                                    <td><?php echo $row['item_id']; ?></td>
                                    <td><?php echo $row['item_name']; ?></td>
                                    <td><?php echo $row['item_description']; ?></td>
                                    <td><?php echo $row['quantity']; ?></td>
                                    <td><?php echo $row['item_type']; ?></td>
                                    <td><?php echo $row['dept_name']; ?></td>
                                    <td><?php echo $row['date_register']; ?></td>

                                    <td>

                                        <button class="btn btn-primary btn-sm"
                                            data-toggle="modal"
                                            data-target="#updateModal<?php echo $row['item_id']; ?>">
                                            <i class="fas fa-edit"></i> Update
                                        </button>

                                        <a href="delete_item.php?id=<?php echo $row['item_id']; ?>"
                                            class="btn btn-secondary btn-sm"
                                            onclick="return confirm('Are you sure?')">
                                            Delete
                                        </a>

                                    </td>
                                </tr>

                                <!-- UPDATE MODAL -->
                                <div class="modal fade" id="updateModal<?php echo $row['item_id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">

                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title">
                                    <i class="fas fa-edit"></i> Update Item
                                    </h5>

                                    <button type="button" class="close text-white" data-dismiss="modal">
                                        <span>&times;</span>
                                    </button>
                                </div>

                                <form method="POST">

                                <!-- THIS IS VERY IMPORTANT  HIDDEN -->
                                <input type="hidden" name="update_id" value="<?php echo $row['item_id']; ?>">

                                <div class="modal-body">

                                    <!-- SHOW ITEM ID READONLY -->
                                    <div class="form-group">
                                        <label>Item ID</label>
                                        <input type="text" class="form-control"
                                            value="<?php echo $row['item_id']; ?>"
                                            readonly>
                                    </div>

                                    <div class="form-group">
                                        <label>Item Name</label>
                                        <input type="text" name="item_name" class="form-control"
                                        value="<?php echo $row['item_name']; ?>" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="item_description" class="form-control"><?php echo $row['item_description']; ?></textarea>
                                    </div>

                                    <div class="form-group">
                                         <label>Quantity</label>
                                        <input type="number" name="quantity" class="form-control"
                                        value="<?php echo $row['quantity']; ?>" required>
                                     </div>

                                    <div class="form-group">
                                        <label>Type</label>
                                        <input type="text" name="item_type" class="form-control"
                                        value="<?php echo $row['item_type']; ?>" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Department</label>
                                        <select name="dept_id" class="form-control" required>
                                            <option value="">Select Department</option>

                                            <?php
                                            // Get departments
                                            $deptModalQuery = $conn->query("SELECT * FROM dept_tbl ORDER BY dept_name ASC");

                                            if($deptModalQuery){
                                                while($dept = $deptModalQuery->fetch_assoc()){
                                            ?>

                                            <option value="<?php echo $dept['dept_id']; ?>"
                                                <?php 
                                                    // Auto select current department
                                                    if(isset($row['dept_id']) && $row['dept_id'] == $dept['dept_id']){
                                                        echo "selected";
                                                    }
                                                ?>>
                                                <?php echo $dept['dept_name']; ?>
                                            </option>

                                            <?php
                                                }
                                            }
                                            ?>

                                        </select>
                                    </div>

                                </div>

                                            <div class="modal-footer">

                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Close
                                                    </button>

                                                <button type="submit" name="update_item" class="btn btn-primary">
                                                    <i class="fas fa-save"></i> Update Item
                                                    </button>

                                                </div>

                                    </form>

                                    </div>
                                    </div>
                                    </div>

                                    <?php
                                    }
                                    } else {
                                echo "<tr>
                                    <td colspan='8' class='text-center'>No Items Found</td>
                                        </tr>";
                                    }
                                ?>

                            
                            </table>

                        </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto text-center">
                <span>&copy; SCC Inventory System 2026</span>
            </div>
        </footer>

    </div>
</div>

    <!-- ================= ADD ITEM MODAL ================= -->

        <div class="modal fade" id="addItemModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
        <div class="modal-content">

        <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Add New Item</h5>
        <button type="button" class="close text-white" data-dismiss="modal">
        <span>&times;</span>
        </button>
        </div>

        <div class="modal-body">

        <?php
        // GET DEPARTMENTS
        $dept_result = $conn->query("SELECT * FROM dept_tbl");

        // INSERT DATA
        if (isset($_POST['save_item'])) {

            $item_id = $_POST['item_id'];
            $item_name = $_POST['item_name'];
            $item_description = $_POST['item_description'];
            $quantity = $_POST['quantity'];
            $item_type = $_POST['item_type'];
            $dept_id = $_POST['dept_id'];
            $date_register = date("Y-m-d");

            $stmt = $conn->prepare("INSERT INTO item_tbl 
                (item_id, item_name, item_description, quantity, item_type, dept_id, date_register)
                VALUES (?, ?, ?, ?, ?, ?, ?)");

            $stmt->bind_param(
                "sssisis",
                $item_id,
                $item_name,
                $item_description,
                $quantity,
                $item_type,
                $dept_id,
                $date_register
            );

            if ($stmt->execute()) {
                echo "<script>window.location='list_of_items.php';</script>";
                exit();
            } else {
                echo "<div class='alert alert-danger'>Error inserting item!</div>";
            }

            $stmt->close();
        }
        ?>

        <form method="POST">

        <div class="form-group">
        <label>Item ID</label>
        <input type="text" name="item_id" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Item Name</label>
        <input type="text" name="item_name" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Description</label>
        <textarea name="item_description" class="form-control"></textarea>
        </div>

        <div class="form-group">
        <label>Quantity</label>
        <input type="number" name="quantity" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Type</label>
        <input type="text" name="item_type" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Department</label>
        <select name="dept_id" class="form-control" required>
        <option value="">Select Department</option>

        <?php
        if($dept_result){
        while($dept = $dept_result->fetch_assoc()){
        echo "<option value='".$dept['dept_id']."'>".$dept['dept_name']."</option>";
        }
        }
        ?>

        </select>
        </div>

        </div>

        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
        Close
        </button>

        <button type="submit" name="save_item" class="btn btn-primary"><i class="fas fa-save"></i> 
        Save Item
        </button>

        </form>

        </div>
        </div>
        </div>
        </div>

    <!-- Alerts Script-->
    <script>setTimeout(function(){$('.alert').fadeOut('slow');},3000);</script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>